from System import Int16

if (starting):
   mousex = 0
   mousey = 0
   xlimit = 15600
   ylimit = 15600

mousex = mousex + (mouse.deltaX * 40)
mousey = mousey + (mouse.deltaY * 80)

if (mouse.middleButton):
    mousex = 0
    mousey = 0

if (mousex > xlimit): mousex = xlimit
if (mousex < -xlimit): mousex = -xlimit
if (mousey > ylimit): mousey = ylimit
if (mousey < -ylimit): mousey = -ylimit

vJoy[0].x = mousex
vJoy[0].y = mousey

diagnostics.watch(vJoy[0].x)
diagnostics.watch(vJoy[0].y)